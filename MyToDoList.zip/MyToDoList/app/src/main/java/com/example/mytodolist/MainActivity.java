package com.example.mytodolist;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText myEditText;
    private Button myButton;
    private LinearLayout listContainer;
    private TextView dateTextView;
    private ArrayList<CheckBox> checkboxList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myEditText = findViewById(R.id.myEditText);
        myButton = findViewById(R.id.myButton);
        listContainer = findViewById(R.id.listContainer);
        dateTextView = findViewById(R.id.dateTextView);

        Calendar calendar = Calendar.getInstance();
        Date today = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String formattedDate = dateFormat.format(today);
        String predefinitoText = "Inserisci gli impegni che vuoi completare oggi: ";
        String dataText = formattedDate;
        dateTextView.setText(predefinitoText + dataText);

        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aggiungiVoce();
            }
        });

        myEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER) && event.getAction() == KeyEvent.ACTION_DOWN) {
                    aggiungiVoce();
                    return true;
                }
                return false;
            }
        });
    }
    private void aggiungiVoce() {
        String text = myEditText.getText().toString();
        if (!text.isEmpty()) {
            CheckBox checkBox = new CheckBox(MainActivity.this);
            checkBox.setText(text);
            checkBox.setTextSize(20);

            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int spuntate = 0;
                    for (int i = 0; i < checkboxList.size(); i++) {
                        if (checkboxList.get(i).isChecked()) {
                            spuntate++;
                        }
                    }
                    if (spuntate == checkboxList.size()) {
                        Toast.makeText(getApplicationContext(), "Hai completato tutti gli impegni di oggi, grande!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Hai completato " + spuntate + " su " + checkboxList.size() + " impegni, continua così!", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            listContainer.addView(checkBox);
            checkboxList.add(checkBox);

            myEditText.setText("");
            myEditText.setHint("Scrivi qui");

            Toast.makeText(getApplicationContext(), "Voce aggiunta!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "Scrivi qualcosa prima di aggiungere alla lista", Toast.LENGTH_SHORT).show();
        }
    }
}